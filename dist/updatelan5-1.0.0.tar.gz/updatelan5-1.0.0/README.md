# UpdateLan5

Ứng dụng quản lý biểu mẫu và tạo tài liệu

## Cài đặt

### Cài đặt từ file wheel

```bash
pip install dist/updatelan5-1.0.0-py3-none-any.whl
```

### Cài đặt từ mã nguồn

```bash
pip install dist/updatelan5-1.0.0.tar.gz
```

hoặc

```bash
pip install -e .
```

## Sử dụng

Sau khi cài đặt, bạn có thể chạy ứng dụng bằng lệnh:

```bash
updatelan5
```

hoặc chạy trực tiếp từ mã nguồn:

```bash
python app.py
```

## Yêu cầu hệ thống

- Python 3.8 trở lên
- Các thư viện phụ thuộc được liệt kê trong file requirements.txt